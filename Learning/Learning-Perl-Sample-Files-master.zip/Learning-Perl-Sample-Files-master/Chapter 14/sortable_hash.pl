# This is the hash of first and last names to be used in the
# case-insensitive sorting exercise at the end of Chapter 14, Strings
# and Sorting. Copy this text into your program, or edit this file and
# save it under a new name.

my %last_name = qw{ 
	fred flintstone Wilma Flintstone Barney Rubble
	betty rubble Bamm-Bamm Rubble PEBBLES FLINTSTONE
};
